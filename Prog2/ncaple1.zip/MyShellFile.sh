gcc MyProgram.c -o MyProgram
./MyProgram > out.txt
